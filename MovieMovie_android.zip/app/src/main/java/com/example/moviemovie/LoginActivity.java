package com.example.moviemovie;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.moviemovie.admin.AdminActivity;
import com.example.moviemovie.find.FindActivity;
import com.example.moviemovie.signup.SignUpActivity;
import com.example.moviemovie.support.PermissionSupport;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.kakao.auth.AuthType;
import com.kakao.auth.ISessionCallback;
import com.kakao.auth.Session;
import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.MeV2ResponseCallback;
import com.kakao.usermgmt.response.MeV2Response;
import com.kakao.util.exception.KakaoException;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import cz.msebera.android.httpclient.Header;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    //객체 생성
    EditText editTextViewId,editTextViewPw;
    Button buttonKakao, buttonFacebook, buttonSignUp, buttonLogin, buttonFind;
    // 카카오톡
    private SessionCallback sessionCallback;
    Session session;
    // 페이스북
    private LoginCallback mLoginCallback;
    private CallbackManager mCallbackManager;

    //로그인 서버 연결
    AsyncHttpClient client;
    HttpResponse response;

    //로그인에 필요한 값
    String id = null;
    String pw = null;

    // 집
    String url = "http://192.168.0.165:8081/moviemovie/member/member_login.do";
    // 학원
    // String url = "http://192.168.1.69:8081/moviemovie/member/member_login.do";

    //로그인 아이디 비밀번호 저장
    public static SharedPreferences pref;
    public static SharedPreferences.Editor editor;

    private PermissionSupport permission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //로그인 아이디 비밀번호 저장
        pref = getApplicationContext().getSharedPreferences("BuyyaPref", MODE_PRIVATE);
        editor = pref.edit();

        /// 객체 초기화
        buttonKakao = findViewById(R.id.buttonKakao);
        buttonFacebook = findViewById(R.id.buttonFacebook);
        buttonSignUp = findViewById(R.id.buttonSignUp);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonFind = findViewById(R.id.buttonFind);
        editTextViewId = findViewById(R.id.editTextViewId);
        editTextViewPw = findViewById(R.id.editTextViewPw);
        client = new AsyncHttpClient();
        response = new HttpResponse();
        // 카카오톡 세션
        sessionCallback = new SessionCallback();
        session = Session.getCurrentSession();
        session.addCallback(sessionCallback);
//        session.checkAndImplicitOpen();
        // 페이스북 세션
        mCallbackManager = CallbackManager.Factory.create();
        mLoginCallback = new LoginCallback();
        // 이벤트 처리
        buttonKakao.setOnClickListener(this);
        buttonFacebook.setOnClickListener(this);
        buttonSignUp.setOnClickListener(this);
        buttonLogin.setOnClickListener(this);
        buttonFind.setOnClickListener(this);

        permissionCheck();

//        getHashKey();

        if(pref.getString("id",null) != null && pref.getString("pw",null) != null ){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }
    }

//    private void getHashKey()
//    {
//        PackageInfo packageInfo = null;
//        try
//        {
//            packageInfo = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
//        }
//        catch (PackageManager.NameNotFoundException e)
//        {
//            e.printStackTrace();
//        }
//        if (packageInfo == null)
//            Log.e("KeyHash", "KeyHash:null");
//
//        for (Signature signature : packageInfo.signatures)
//        {
//            try
//            {
//                MessageDigest md = MessageDigest.getInstance("SHA");
//                md.update(signature.toByteArray());
//                Log.e("KeyHash", Base64.encodeToString(md.digest(), Base64.DEFAULT));
//            }
//            catch (NoSuchAlgorithmException e)
//            {
//                Log.e("KeyHash", "Unable to get MessageDigest. signature=" + signature, e);
//            }
//        }
//    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch (v.getId()) {
            case R.id.buttonFacebook:
                LoginManager loginManager = LoginManager.getInstance();
                loginManager.logInWithReadPermissions(LoginActivity.this,
                        Arrays.asList("public_profile", "email"));
                loginManager.registerCallback(mCallbackManager, mLoginCallback);
                break;
            case R.id.buttonKakao:
                session.open(AuthType.KAKAO_LOGIN_ALL, LoginActivity.this);
                break;
            case R.id.buttonSignUp:
                intent = new Intent(this, SignUpActivity.class);
                startActivity(intent);
                break;
            case R.id.buttonLogin:
                id = editTextViewId.getText().toString().trim();
                pw = editTextViewPw.getText().toString().trim();

                // 관리자 id : moviemovie, pw : movie!
                if(id.equals("moviemovie") && pw.equals("movie!")) {
                    intent = new Intent(this, AdminActivity.class);
                    startActivity(intent);
                } else {
                    RequestParams params = new RequestParams();
                    params.put("id", id);
                    params.put("pw", pw);
                    client.post(url, params, response);
                }
                break;
            case R.id.buttonFind:
                intent = new Intent(this, FindActivity.class);
                startActivity(intent);
                break;
        }
    }

    class HttpResponse extends AsyncHttpResponseHandler {

        @Override
        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
            String str = new String(responseBody);
            Intent intent = null;
            try {
                JSONObject json = new JSONObject(str);
                String rt = json.getString("rt");
                if(rt.equals("OK")) {
                    Toast.makeText(LoginActivity.this,"로그인 성공", Toast.LENGTH_SHORT).show();
                    editor.putString("id",id);
                    editor.putString("pw",pw);
                    editor.commit();

                    intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this,"아이디와 패스워드를 확인해주세요", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
//            Toast.makeText(LoginActivity.this,"통신 실패", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 세션 콜백 삭제
        Session.getCurrentSession().removeCallback(sessionCallback);
    }

    private class SessionCallback implements ISessionCallback {
        // 로그인 성공
        @Override
        public void onSessionOpened() {
            requestMe();
            Toast.makeText(LoginActivity.this, "카카오톡 로그인 성공", Toast.LENGTH_SHORT).show();
        }

        // 로그인 실패
        @Override
        public void onSessionOpenFailed(KakaoException exception) {
            Log.e("SessionCallback: ", "onSessionOpenFailed: " + exception.getMessage());
        }

        // 사용자 정보 요청
        public void requestMe() {
            UserManagement.getInstance().me(new MeV2ResponseCallback() {
                @Override
                public void onSessionClosed(ErrorResult errorResult) {
                    Log.e("KAKAO_API", "세션이 닫혀 있음: " + errorResult);
                }

                @Override
                public void onFailure(ErrorResult errorResult) {
                    Log.e("KAKAO_API", "사용자 정보 요청 실패: " + errorResult);
                }

                @Override
                public void onSuccess(MeV2Response result) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    Log.i("KAKAO_API", "user id: " + result.getId());
//                    UserAccount kakaoAccount = result.getKakaoAccount();
//                    if (kakaoAccount != null) {
//
//                        // 이메일
//                        String email = kakaoAccount.getEmail();
//
//                        if (email != null) {
//                            Log.i("KAKAO_API", "email: " + email);
//
//                        } else if (kakaoAccount.emailNeedsAgreement() == OptionalBoolean.TRUE) {
//                            // 동의 요청 후 이메일 획득 가능
//                            // 단, 선택 동의로 설정되어 있다면 서비스 이용 시나리오 상에서 반드시 필요한 경우에만 요청해야 합니다.
//
//                        } else {
//                            // 이메일 획득 불가
//                        }
//
//                        // 프로필
//                        Profile profile = kakaoAccount.getProfile();
//
//                        if (profile != null) {
//                            Log.d("KAKAO_API", "nickname: " + profile.getNickname());
//                            Log.d("KAKAO_API", "profile image: " + profile.getProfileImageUrl());
//                            Log.d("KAKAO_API", "thumbnail image: " + profile.getThumbnailImageUrl());
//
//                        } else if (kakaoAccount.profileNeedsAgreement() == OptionalBoolean.TRUE) {
//                            // 동의 요청 후 프로필 정보 획득 가능
//
//                        } else {
//                        }
//                    }
                }
            });
        }
    }

    private class LoginCallback implements FacebookCallback<LoginResult> {
        // 로그인 성공
        @Override
        public void onSuccess(LoginResult loginResult) {
            Log.e("Callback:: ", "onSuccess");
            Toast.makeText(LoginActivity.this, "페이스북 로그인 성공", Toast.LENGTH_SHORT).show();
            requestMe(loginResult.getAccessToken());
        }

        // 로그인 창 닫을 경우
        @Override
        public void onCancel() {
            Log.e("Callback:: ", "onCancel");
        }

        // 로그인 실패
        @Override
        public void onError(FacebookException error) {
            Log.e("Callback:: ", "onError: " + error.getMessage());
        }

        public void requestMe(AccessToken token) {
            GraphRequest graphRequest = GraphRequest.newMeRequest(token, new GraphRequest.GraphJSONObjectCallback() {
                @Override
                public void onCompleted(JSONObject object, GraphResponse response) {
                    Log.e("result", object.toString());
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "id, name, email, gender, birthday");
            graphRequest.setParameters(parameters);
            graphRequest.executeAsync();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // 카카오톡 간편 로그인 실행 결과를 받아서 SDK로 전달
        if (Session.getCurrentSession().handleActivityResult(requestCode, resultCode, data)) {
//            Intent intent = new Intent(getApplicationContext(), MyPageActivity.class);
//            startActivity(intent);
            return;
        }
        // 페이스북
        mCallbackManager.onActivityResult(requestCode, resultCode, data);

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void permissionCheck() {
        if(Build.VERSION.SDK_INT>=23){
            permission = new PermissionSupport(this,this);

            if(!permission.checkPermission()){
                permission.requestPermission();
            }
        }

    }
}