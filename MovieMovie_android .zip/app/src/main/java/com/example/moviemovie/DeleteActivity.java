package com.example.moviemovie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.moviemovie.find.FindPWActivity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

import static com.example.moviemovie.LoginActivity.editor;
import static com.example.moviemovie.LoginActivity.pref;

public class DeleteActivity extends AppCompatActivity implements View.OnClickListener {
    TextView textView_delete_id;
    EditText editText_delete_pw;
    Button button_back_delete, button_confirm_delete;
    AsyncHttpClient client;
    HttpResponse response;
    HttpResponseGenreDelete responseGenreDelete;
    String id = pref.getString("id",null);
    String pw = pref.getString("pw",null);
    int seq = pref.getInt("seq", 0);
    // 집
    String url = "http://192.168.0.165:8081/moviemovie/member/member_delete.do";
    // 학원
    // String url = "http://192.168.1.69:8081/moviemovie/member/member_delete.do";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        textView_delete_id = findViewById(R.id.textView_delete_id);
        editText_delete_pw = findViewById(R.id.editText_delete_pw);
        button_back_delete = findViewById(R.id.button_back_delete);
        button_confirm_delete = findViewById(R.id.button_confirm_delete);
        client = new AsyncHttpClient();
        response = new HttpResponse();
        responseGenreDelete = new HttpResponseGenreDelete();

        textView_delete_id.setText(id);

        button_back_delete.setOnClickListener(this);
        button_confirm_delete.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_back_delete:
                finish();
                break;
            case R.id.button_confirm_delete:
                String checkPW = editText_delete_pw.getText().toString().trim();
                if(checkPW.equals("")) {
                    Toast.makeText(this, "비밀번호를 입력해주세요", Toast.LENGTH_SHORT).show();
                } else if(!checkPW.equals(pw)) {
                    Toast.makeText(this, "비밀번호가 일치하지 않습니다", Toast.LENGTH_SHORT).show();
                } else {
                    genreDelete();
                    RequestParams params = new RequestParams();
                    Log.d("[TEST]", "seq : " + seq);
                    params.put("seq", seq);
                    params.put("pw", checkPW);
                    client.post(url, params, response);
                    finish();
                }
                break;
        }
    }

    private void genreDelete() {
        String url = "http://192.168.0.165:8081/moviemovie/genre/genreDelete.do";
        RequestParams params = new RequestParams();
        params.put("id", id);
        client.post(url, params, response);
        finish();
    }

    class HttpResponse extends AsyncHttpResponseHandler {

        @Override
        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
            String str = new String(responseBody);

            try {
                JSONObject json = new JSONObject(str);
                String rt = json.getString("rt");
                if(rt.equals("OK")) {
                    Toast.makeText(DeleteActivity.this, "탈퇴 성공", Toast.LENGTH_SHORT).show();
                    editor.clear();
                    editor.commit();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Intent intent = new Intent(DeleteActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        @Override
        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
            Toast.makeText(DeleteActivity.this,"통신 실패", Toast.LENGTH_SHORT).show();
        }
    }

    class HttpResponseGenreDelete extends AsyncHttpResponseHandler {

        @Override
        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
            String str = new String(responseBody);

            try {
                JSONObject json = new JSONObject(str);
                String rt = json.getString("rt");
                if(rt.equals("OK")) {
                    Toast.makeText(DeleteActivity.this, "장르 삭제 성공", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
            Toast.makeText(DeleteActivity.this,"통신 실패", Toast.LENGTH_SHORT).show();
        }
    }
}