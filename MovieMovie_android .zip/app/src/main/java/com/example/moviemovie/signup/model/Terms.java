package com.example.moviemovie.signup.model;

public class Terms {

    private String text;

    public Terms() {
    }

    public Terms(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
