package com.example.moviemovie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.moviemovie.calendar.CalendarActivity;
import com.example.moviemovie.cs.CSActivity;
import com.example.moviemovie.information.FilmActivity;
import com.example.moviemovie.review.ListFragment;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

import static com.example.moviemovie.LoginActivity.editor;
import static com.example.moviemovie.LoginActivity.pref;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView textView_nickname, textView_myReview, textView_myTime;
    AsyncHttpClient client;
    HttpResponse response;
    HttpResponseReviewTotal responseReviewTotal;
    Button button_cal, button_info, button_home, button_my, button_serv;
    String email,tel,nickName,img=null;
    String id = pref.getString("id",null);
    int seq;
    ListFragment listFragment;
    // 집
    String url ="http://192.168.0.165:8081/moviemovie/member/getMember.do";
    // 학원
    // String url ="http://192.168.1.69:8081/moviemovie/member/getMember.do";
    // 집
    String url_reviewTotal ="http://192.168.0.165:8081/moviemovie/review/review_total.do";
    // 학원
    // String url_reviewTotal ="http://192.168.1.69:8081/moviemovie/review/review_total.do";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView_nickname = findViewById(R.id.textView_nickname);
        textView_myReview = findViewById(R.id.textView_myReview);
        textView_myTime = findViewById(R.id.textView_myTime);
        client = new AsyncHttpClient();
        response = new HttpResponse();
        responseReviewTotal = new HttpResponseReviewTotal();
        button_cal = findViewById(R.id.button_cal);
        button_info = findViewById(R.id.button_info);
        button_home = findViewById(R.id.button_home);
        button_my = findViewById(R.id.button_my);
        button_serv = findViewById(R.id.button_serv);
        listFragment = new ListFragment();

        button_cal.setOnClickListener(this);
        button_info.setOnClickListener(this);
        button_home.setOnClickListener(this);
        button_my.setOnClickListener(this);
        button_serv.setOnClickListener(this);

        if(pref.getString("id",null) != null && pref.getString("pw",null) != null ){
            editor.putString("email", email);
            editor.putString("tel", tel);
            editor.putString("nickName", nickName);
            if(img != null){
                editor.putString("img", img);
            }
            editor.commit();
        }

        getReviewTotal();

    }

    private void getReviewTotal() {
        RequestParams params = new RequestParams();
        params.put("id", id);
        client.post(url_reviewTotal, params, responseReviewTotal);
    }

    @Override
    protected void onResume() {
        super.onResume();
        RequestParams params = new RequestParams();
        params.put("id", id);
        client.post(url, params, response);
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch (v.getId()) {
            case R.id.button_cal:       // 캘린더
                intent = new Intent(this, CalendarActivity.class);
                startActivity(intent);
                break;
            case R.id.button_info:      // 영화정보
                intent = new Intent(this, FilmActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
                break;
            case R.id.button_home:      // 홈
//                intent = new Intent(this, MainActivity.class);
//                startActivity(intent);
                Toast.makeText(this, "현재 위치입니다", Toast.LENGTH_SHORT).show();
                break;
            case R.id.button_my:        // 마이페이지
                intent = new Intent(this, SettingActivity.class);
                startActivity(intent);
                break;
            case R.id.button_serv:      // 고객센터
                intent = new Intent(this, CSActivity.class);
                startActivity(intent);
                break;
        }
    }

    class HttpResponse extends AsyncHttpResponseHandler {

        @Override
        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
            String str = new String(responseBody);
            try {
                JSONObject json = new JSONObject(str);
                String rt = json.getString("rt");
                email = json.getString("email");
                tel = json.getString("tel");
                nickName = json.getString("nickName");
                img = json.getString("img");
                seq = json.getInt("seq");

                editor.putString("email",email);
                editor.putString("tel",tel);
                editor.putString("nickName",nickName);
                if(img != null) {
                    editor.putString("img", img);
                }
                editor.putInt("seq", seq);
                editor.commit();

                if(rt.equals("OK")) {
                    textView_nickname.setText(nickName);
                } else {
//                    Toast.makeText(MainActivity.this,"닉네임 실패", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
//            Toast.makeText(MainActivity.this,"통신 실패", Toast.LENGTH_SHORT).show();
        }
    }

    class HttpResponseReviewTotal extends AsyncHttpResponseHandler {

        @Override
        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
            String str = new String(responseBody);
            try {
                JSONObject json = new JSONObject(str);
                String rt = json.getString("rt");
                int totalCnt = json.getInt("totalCnt");
                String myReview  = String.valueOf(totalCnt);
                if(rt.equals("OK")) {
                    String totalRuntime = json.getString("totalRuntime");
                    textView_myReview.setText(" " + totalCnt + "개");
                    textView_myTime.setText(" " + totalRuntime + "분");
                } else {
                    textView_myReview.setText(" " + 0 + "개");
                    textView_myTime.setText(" " + 0 + "분");
                }
                editor.putString("myReview", myReview);
                editor.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
//            Toast.makeText(MainActivity.this,"통신 실패", Toast.LENGTH_SHORT).show();
        }
    }
}