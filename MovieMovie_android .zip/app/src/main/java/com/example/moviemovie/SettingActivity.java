package com.example.moviemovie;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.moviemovie.calendar.CalendarActivity;
import com.example.moviemovie.cs.CSActivity;
import com.example.moviemovie.information.FilmActivity;
import com.example.moviemovie.modify.ModifyActivity;
import com.example.moviemovie.modify.ModifyPWActivity;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.moviemovie.LoginActivity.editor;
import static com.example.moviemovie.LoginActivity.pref;

public class SettingActivity extends AppCompatActivity implements View.OnClickListener {
    Button buttonEditPr, buttonEditPw, buttonLogout, buttonSignout;
    Button button_cal, button_info, button_home, button_my, button_serv;
    TextView textView_nicknameSET;
    CircleImageView imageView_profile, imageView_grade;
    String id = pref.getString("id",null);
    String nickName = pref.getString("nickName", null);
    String img = pref.getString("img", null);
    String myReview = pref.getString("myReview",null);
    int cntReview;
    // 집
    String url ="http://192.168.0.165:8081/moviemovie/member/getMember.do";
    // 학원
    // String url ="http://192.168.1.69:8081/moviemovie/member/getMember.do";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        buttonEditPr = findViewById(R.id.buttonEditPr);
        buttonEditPw = findViewById(R.id.buttonEditPw);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonSignout = findViewById(R.id.buttonSignout);
        button_cal = findViewById(R.id.button_cal);
        button_info = findViewById(R.id.button_info);
        button_home = findViewById(R.id.button_home);
        button_my = findViewById(R.id.button_my);
        button_serv = findViewById(R.id.button_serv);
        textView_nicknameSET = findViewById(R.id.textView_nicknameSET);
        imageView_profile = findViewById(R.id.imageView_profile);
        imageView_grade = findViewById(R.id.imageView_grade);

        if(myReview.equals("")) {
            cntReview = 0;
        } else {
            cntReview = Integer.parseInt(myReview);
        }

//        Log.d("[TEST]", myReview);

        textView_nicknameSET.setText(nickName);
        if(img.equals("X")) {
            Glide.with(this).load(R.drawable.moviemovie_profile).into(imageView_profile);
        } else if(!img.equals("X")) {
            Glide.with(this).load(img).into(imageView_profile);
        }

        switch (cntReview) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                Glide.with(this).load(R.drawable.moviemovie_membership2_1).into(imageView_grade);
                break;
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
                Glide.with(this).load(R.drawable.moviemovie_membership2_2).into(imageView_grade);
                break;
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
                Glide.with(this).load(R.drawable.moviemovie_membership2_3).into(imageView_grade);
                break;
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
                Glide.with(this).load(R.drawable.moviemovie_membership2_4).into(imageView_grade);
                break;
            default:
                Glide.with(this).load(R.drawable.moviemovie_membership2_5).into(imageView_grade);
                break;
        }

        buttonEditPr.setOnClickListener(this);
        buttonEditPw.setOnClickListener(this);
        buttonLogout.setOnClickListener(this);
        buttonSignout.setOnClickListener(this);
        button_cal.setOnClickListener(this);
        button_info.setOnClickListener(this);
        button_home.setOnClickListener(this);
        button_my.setOnClickListener(this);
        button_serv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch (v.getId()) {
            case R.id.buttonEditPr:
                intent = new Intent(this, ModifyActivity.class);
                startActivity(intent);
                break;
            case R.id.buttonEditPw:
                intent = new Intent(this, ModifyPWActivity.class);
                startActivity(intent);
                break;
            case R.id.buttonLogout:
                Toast.makeText(getApplicationContext(), "로그아웃되었습니다", Toast.LENGTH_SHORT).show();
                UserManagement.getInstance().requestLogout(new LogoutResponseCallback() { //로그아웃 실행
                    @Override
                    public void onCompleteLogout() {
                        //로그아웃 성공 시 로그인 화면으로 이동
                        Intent intent = new Intent(SettingActivity.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        editor.clear();
                        editor.commit();
                        startActivity(intent);
                    }
                });
                break;
            case R.id.buttonSignout:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("탈퇴하시겠습니까?");
                builder.setCancelable(false);
                builder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(SettingActivity.this, DeleteActivity.class);
                        startActivity(intent);
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                break;
            case R.id.button_cal:       // 캘린더
                intent = new Intent(this, CalendarActivity.class);
                startActivity(intent);
                break;
            case R.id.button_info:      // 영화정보
                intent = new Intent(this, FilmActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
                break;
            case R.id.button_home:      // 홈
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
            case R.id.button_my:        // 마이페이지
//                intent = new Intent(this, SettingActivity.class);
//                startActivity(intent);
                Toast.makeText(this, "현재 위치입니다", Toast.LENGTH_SHORT).show();
                break;
            case R.id.button_serv:      // 고객센터
                intent = new Intent(this, CSActivity.class);
                startActivity(intent);
                break;
        }
    }
}